package src;

import java.util.List;

public interface ISortingUtility {
	public List<Product> sort(List<Product> items, int sortingApproach);
}
