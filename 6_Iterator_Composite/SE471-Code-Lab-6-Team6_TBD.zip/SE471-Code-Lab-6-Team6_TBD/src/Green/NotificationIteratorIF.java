//  NotificationIteratorIF.java

package src.Green;

import src.Blue.Notification;

public interface NotificationIteratorIF {
    public boolean hasNext();
    public Notification next();
}
