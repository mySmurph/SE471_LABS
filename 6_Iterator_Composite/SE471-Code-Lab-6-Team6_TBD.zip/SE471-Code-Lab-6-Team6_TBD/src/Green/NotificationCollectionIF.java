//  NotificationCollectionIF.java

package src.Green;

public interface NotificationCollectionIF {
    public NotificationIteratorIF createIterator();
}
