package AgentDemo;

public interface Agent_IF {
	public void startTask();
	public void stopTask();
	public void setTaskID(int id);
}
