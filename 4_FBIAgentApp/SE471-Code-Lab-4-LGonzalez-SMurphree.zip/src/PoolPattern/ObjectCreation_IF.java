package PoolPattern;

public interface ObjectCreation_IF {
	public Object create();
}
